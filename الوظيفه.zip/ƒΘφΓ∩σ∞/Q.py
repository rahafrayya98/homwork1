Python 3.8.0 (tags/v3.8.0:fa919fd, Oct 14 2019, 19:37:50) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> studentsgraduat=['rahaf', 'ammar', 'manar', 'nour', 'jafar', 'rami']
graduatname=input('Enter your name:')
if graduatname in studentsgraduat :
    print (graduatname,'yes, you did It ', "\U0001F070")
else:
    print (graduatname, 'no, betterluck', "\U0001F620")
