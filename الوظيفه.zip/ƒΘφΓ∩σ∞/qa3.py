L=["Network" , "Math" , "Programming", "Physics" , "Music"]
for i in range(len(L)):
    if(L[i][0]=="P"):
        print(L[i])
    
