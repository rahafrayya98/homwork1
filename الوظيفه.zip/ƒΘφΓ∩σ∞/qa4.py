R=['Network', 'math', 'programing', 'phisic', 'music'] 
for i in range(len(R))
if (R[i][o]== "p")
print [R[i]]
