R=[i for i in range(1,1001,2)]
print (R)
